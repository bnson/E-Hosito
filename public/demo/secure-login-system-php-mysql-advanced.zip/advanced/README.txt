Thank you for purchasing from CodeShack!

If you have any issues don't hesitate to contact us via our website: https://codeshack.io