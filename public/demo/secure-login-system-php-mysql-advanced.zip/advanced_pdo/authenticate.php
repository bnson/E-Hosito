<?php
session_start();
// Change this to your connection info.
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'phplogin';
// Try and connect using the info above.
try {
	$pdo = new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME . ';charset=utf8', $DATABASE_USER, $DATABASE_PASS);
} catch (PDOException $exception) {
	// If there is an error with the connection, stop the script and display the error.
	die ('Failed to connect to database!');
}
// Now we check if the data from the login form was submitted, isset() will check if the data exists.
if (!isset($_POST['username'], $_POST['password'])) {
	// Could not get the data that should have been sent.
	die ('Please fill both the username and password field!');
}
// Prepare our SQL, preparing the SQL statement will prevent SQL injection.
$stmt = $pdo->prepare('SELECT * FROM accounts WHERE username = ?');
// Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"
$stmt->execute([$_POST['username']]);
$account = $stmt->fetch(PDO::FETCH_ASSOC);
// If the username exiusts
if ($account) {
	// Account exists, now we verify the password.
	// Note: remember to use password_hash in your registration file to store the hashed passwords.
	if (password_verify($_POST['password'], $account['password'])) {
		// Verification success! User has loggedin!
		// Create sessions so we know the user is logged in, they basically act like cookies but remember the data on the server.
		session_regenerate_id();
		$_SESSION['loggedin'] = TRUE;
		$_SESSION['name'] = $account['username'];
		$_SESSION['id'] = $account['id'];
		// IF the user checked the remember me check box:
		if (isset($_POST['rememberme'])) {
			// Create a hash that will be stored as a cookie and in the database, this will be used to identify the user.
			$cookiehash = password_hash($account['id'] . $account['username'] . 'yoursecretkey', PASSWORD_DEFAULT);
			// The amount of days a user will be remembered:
			$days = 30;
			setcookie('rememberme', $cookiehash, time() + ($days * 24 * 60 * 60 * 1000));
			/// Update the "rememberme" field in the accounts table
			$stmt = $pdo->prepare('UPDATE accounts SET rememberme = ? WHERE id = ?');
			$stmt->execute([$cookiehash, $account['id']]);
		}
		echo 'Success';
	} else {
		echo 'Incorrect password!';
	}
} else {
	echo 'Incorrect username!';
}
?>
